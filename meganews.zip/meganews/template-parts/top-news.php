    <?php 

        $aznews_top_news = new WP_Query(
            array(
                'post_type'             =>'top_news',
                'posts_per_page'        => 3,
                'order'                 =>'ASC'
            )
        );

        if($aznews_top_news->have_posts()):

    ?>
    
    <!--   Weekly-News start -->
    <div class="weekly-news-area pt-50">
        <div class="container">
           <div class="weekly-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mb-30">
                            <h3><?php _e('Weekly Top News', 'aznews'); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="weekly-news d-flex">
                        <?php 
                            while($aznews_top_news->have_posts()):
                                $aznews_top_news->the_post();
                        ?>
                            <div class="weekly-single active">
                                <div class="weekly-img">
                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>">
                                </div>
                                <div class="weekly-caption">
                                    <span class="color1"><?php the_category(' '); ?></span>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                </div>
           </div>
        </div>
    </div>           
    <!-- End Weekly-News -->

        <?php endif; ?>