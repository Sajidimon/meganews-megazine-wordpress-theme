<?php

$aznews_featured = new WP_Query(
    array(
        'meta_key'          => 'featured',
        'meta_value'        => '1',
        'posts_per_page'    => 9
    )
);

$post_data = array();
while ($aznews_featured->have_posts()) {
    $aznews_featured->the_post();
    $categories = get_the_category();
    $post_data[] = array(
        "title" => get_the_title(),
        "permalink" => get_the_permalink(),
        "thumbnail" => get_the_post_thumbnail_url(get_the_ID()),
        'cat'   => $categories[0]->name
    );
}

if ($aznews_featured->post_count > 1) :

?>



    <div class="row">
        <div class="col-lg-8">
            <!-- Trending Top -->
            <div class="trending-top mb-30">
                <div class="trend-top-img">
                    <img src="<?php echo esc_url($post_data[0]['thumbnail']); ?>">
                    <div class="trend-top-cap">
                        <span><?php echo esc_html($post_data[0]['cat']); ?></span>
                        <h2><a href="<?php echo esc_url($post_data[0]['permalink']); ?>"><?php echo esc_html($post_data[0]['title']); ?></a></h2>
                    </div>
                </div>
            </div>
            <!-- Trending Bottom -->
            <div class="trending-bottom">
                <div class="row">
                    <?php
                    for ($i = 1; $i < 4; $i++) :
                    ?>
                        <div class="col-lg-4">
                            <div class="single-bottom mb-35">
                                <div class="trend-bottom-img mb-30">
                                    <img src="<?php echo esc_url($post_data[$i]['thumbnail']); ?>">
                                </div>
                                <div class="trend-bottom-cap">
                                    <span class="color1"><?php echo esc_html($post_data[$i]['cat']); ?></span>
                                    <h4><a href="<?php echo esc_url($post_data[$i]['permalink']); ?>"><?php echo esc_html($post_data[$i]['title']); ?></a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <!-- Riht content -->
        <div class="col-lg-4">
            <div class="trand-right-single d-flex">
                <div class="trand-right-img">
                    <img src="<?php echo esc_url($post_data[4]['thumbnail']); ?>">
                </div>
                <div class="trand-right-cap">
                    <span class="color1"><?php echo esc_html($post_data[4]['cat']); ?></span>
                    <h4><a href="<?php echo esc_url($post_data[4]['permalink']); ?>"><?php echo esc_html($post_data[4]['title']); ?></a></h4>
                </div>
            </div>
            <div class="trand-right-single d-flex">
                <div class="trand-right-img">
                    <img src="<?php echo esc_url($post_data[5]['thumbnail']); ?>">
                </div>
                <div class="trand-right-cap">
                    <span class="color3"><?php echo esc_html($post_data[5]['cat']); ?></span>
                    <h4><a href="<?php echo esc_url($post_data[5]['permalink']); ?>"><?php echo esc_html($post_data[5]['title']); ?></a></h4>
                </div>
            </div>
            <div class="trand-right-single d-flex">
                <div class="trand-right-img">
                    <img src="<?php echo esc_url($post_data[6]['thumbnail']); ?>">
                </div>
                <div class="trand-right-cap">
                    <span class="color2"><?php echo esc_html($post_data[6]['cat']); ?></span>
                    <h4><a href="<?php echo esc_url($post_data[6]['permalink']); ?>"><?php echo esc_html($post_data[6]['title']); ?></a></h4>
                </div>
            </div>
            <div class="trand-right-single d-flex">
                <div class="trand-right-img">
                    <img src="<?php echo esc_url($post_data[7]['thumbnail']); ?>">
                </div>
                <div class="trand-right-cap">
                    <span class="color4"><?php echo esc_html($post_data[7]['cat']); ?></span>
                    <h4><a href="<?php echo esc_url($post_data[7]['permalink']); ?>"><?php echo esc_html($post_data[7]['title']); ?></a></h4>
                </div>
            </div>
            <div class="trand-right-single d-flex">
                <div class="trand-right-img">
                    <img src="<?php echo esc_url($post_data[8]['thumbnail']); ?>">
                </div>
                <div class="trand-right-cap">
                    <span class="color1"><?php echo esc_html($post_data[8]['cat']); ?></span>
                    <h4><a href="<?php echo esc_url($post_data[8]['permalink']); ?>"><?php echo esc_html($post_data[8]['title']); ?></a></h4>
                </div>
            </div>
        </div>
    </div>

<?php endif; ?>