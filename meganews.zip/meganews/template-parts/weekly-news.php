  <!--   Weekly2-News start -->
  <?php 

$aznews_top_news2 = new WP_Query(
    array(
        'post_type'             =>'top_news',
        'posts_per_page'        =>4,
        'order'                 =>'DESC'
    )
);

if($aznews_top_news2->have_posts()):
?>
    <div class="weekly2-news-area  weekly2-pading gray-bg">
        <div class="container">
            <div class="weekly2-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mb-30">
                            <h3>Weekly Top News</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="weekly2-news-active dot-style d-flex dot-style">

                        <?php 
                            while($aznews_top_news2->have_posts()):
                                $aznews_top_news2->the_post();
                        ?>
                            <div class="weekly2-single">
                                <div class="weekly2-img">
                                    <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>">
                                </div>
                                <div class="weekly2-caption">
                                    <span class="color1"><?php the_category(' '); ?></span>
                                    <p><?php echo get_the_date(); ?></p>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>           
    <!-- End Weekly-News -->

<?php endif; ?>