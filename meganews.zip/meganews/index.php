<?php get_header(); ?>

<!--================Blog Area =================-->
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <?php
                    while (have_posts()) :
                        the_post();
                    ?>
                        <article <?php post_class('blog_item') ?>>
                            <div class="blog_item_img">
                                <img class="card-img rounded-0" src="<?php echo wp_get_attachment_url(get_post_thumbnail_id($post->ID)); ?>">
                                <a class="blog_item_date">
                                    <p><?php the_time('d M'); ?></p>
                                </a>
                            </div>

                            <div class="blog_details">
                                <a class="d-inline-block" href="<?php the_permalink(); ?>">
                                    <h2><?php the_title(); ?></h2>
                                </a>
                                <p><?php the_excerpt(); ?></p>
                                <ul class="blog-info-link">
                                    <li><i class="fa fa-user"></i> <?php the_category(' '); ?></li>
                                    <li><i class="fa fa-comments"></i> <?php comments_number(); ?></li>
                                </ul>
                            </div>
                        </article>

                    <?php endwhile; ?>

                    <nav class="blog-pagination justify-content-center d-flex">

                        <?php aznews_pagination(); ?>

                    </nav>

                </div>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</section>
<!--================Blog Area =================-->

<?php get_footer(); ?>